
#####################################################
#++++++   Load necesary packages
####################################################
library(rio)
library(data.table)
library(tidyverse)


library(ggrepel)

library(RColorBrewer)
#library(patchwork)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(spData)
library(sf)
library(countrycode)
library(ggthemr)


ggthemr("fresh")


all   %>%
  ggplot(., aes(x=reorder(country, perc, FUN=median), y=perc, fill = outcome) ) +
  geom_boxplot(fill="lightblue", width=.2) + 
  geom_dotplot(binaxis='y', stackdir='center', binwidth = 1.5,
               stackratio=1, dotsize=0.5) + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +  
  ylab("Prevalence (%)") + xlab("") +
  theme(axis.text.y=element_text(size=20)) +
  theme(axis.title=element_text(size=20,face="bold")) + 
  coord_flip() +
  labs(fill = "Outcome type")


dev.copy2pdf(file="./Figures/Figure10_estimates.pdf")
dev.off()


#####################################################
#++++++   Load main data files
####################################################



dataMap <-read_excel("./Data/ITN_Owner_extraction_28Feb.xlsx") %>%
  select(country = Country) %>%
  na.omit()
  






##World map data
country <- dataMap %>% group_by(country) %>%  tally() %>% rename(NAME = country) %>% mutate(region = NAME) 



map.world <- ggplot2::map_data(map="world") %>% 
  filter(region != "Antarctica") %>%
  mutate(continent = countrycode(region, 'country.name', 'continent'))  %>%
  left_join(., country) %>%
  filter(continent == "Africa")


cnames <- aggregate(cbind(long, lat) ~ NAME,
                    data=map.world, FUN=function(x) mean(range(x))) %>% 
  left_join(., country)

 ggplot() + 
  geom_polygon(data = map.world , 
               aes(x = long, y = lat, group = group), 
               color = "black", size = 0.25,  fill = NA) +
  geom_label_repel(
    data = cnames,
    aes(x = long, y = lat, label = paste(NAME, " (n=", n, ")", sep = "") , size = 10),
    box.padding = unit(2, "lines")) +
  geom_point(data = cnames, 
             aes(x = long, y = lat, size= n), 
             color = "black") +
  labs(title = "", size="Studies") +
  scale_size(range = c(1, 10)) +
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank()) +
  theme(axis.title=element_text(size=15,face="bold")) + 
  theme(text = element_text(size=20))   + 
  theme(legend.position="none")

dev.copy2pdf(file="./Figures/Figure11_map.pdf")
dev.off()
