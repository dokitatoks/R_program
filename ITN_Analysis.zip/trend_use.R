library(readxl)
library(purrr)
library(tidyverse)
library(data.table)
library(meta)
library(scales)
library(gridExtra)
library(patchwork)
library(ggthemr)
library(lme4)
library(broom.mixed)


ggthemr("fresh")


path = "./Data/new_data.xlsx"
sheets <- readxl::excel_sheets(path)
sheets


sheets = c("Children_use",   "Women_use",  "All_age_use")

all <- purrr::map_df(sheets, ~dplyr::mutate(readxl::read_excel(path, sheet = .x), 
                                            outcome= .x)) %>%
  mutate(perc = (r/ n)*100,
         studyID = paste0(Author, ", ", Country),
         outcome = recode(outcome,
                          "Children_use" = "Children",
                          "Women_use" = "Women",
                          "All_age_use" = "All ages"))


# Calculate AAPC - average annual percentage change
# From poisson regression
# Nested data ------------------------------------------------------------------------------
trendData <-  all  %>%
  group_by(outcome) %>%
  mutate(N = n()) %>%
  filter(N>=3) 



trendNest<- all %>%
  arrange(Year) %>%
  group_by(outcome) %>%
  mutate(N = n()) %>%
  filter(N>=3) %>%
  group_by(outcome) %>%
  nest()


df_trend <- all %>%
  arrange(Year) %>%
  group_by(outcome) %>%
  summarise(N = n(),
            firstYear = first(Year),
            lastYear = last(Year),
            firstPerc = first(perc),
            lastPerc = last(perc),
            firstPeriod = paste0(firstYear, "->", percent(firstPerc, 0.1, scale = 1)),
            lastPeriod = paste0(lastYear, "->", percent(lastPerc, 0.1, scale = 1)),
            abs_incr = (lastPerc / firstPerc)*100,                         #Absolute increase
            rel_incr = ((lastPerc - firstPerc)/ firstPerc)*100) %>%
  filter(N>=3) 
df_trend



# End of command chunk --------------------------------------------------------------------

# glm(perc ~ year + offset(logSize) , family = poisson, data = df)
# Fit models -------------------------------------------------------------------------------
country_model <- function(df) {
  lmer(log(perc) ~ Year + (1 | Country), data = df)
}


models <- trendNest%>%
  mutate(
    model  = data %>% map(country_model),
    tidy    = model %>% map(broom::tidy, conf.int = TRUE))

df_aapc <- unnest(models, tidy) %>% filter(term == "Year") %>%
  mutate(p.value = 2*pnorm(-abs(statistic)),
         pvalue =sprintf("%4.3f", p.value),
         aapc = 100*(exp(estimate) -1),
         aapc_effect = paste0(sprintf("%4.1f", 100*(exp(estimate) -1)), " (", 
                              sprintf("%4.1f", 100*(exp(conf.low) -1)), " to ", 
                              sprintf("%4.1f", 100*(exp(conf.high) -1)), ")")) %>%
  select(outcome, aapc, aapc_effect, pvalue) 

# End of command chunk --------------------------------------------------------------------



# Export Table 1 --------------------------------------------------------------------------
df_table1 <- df_trend %>% 
  left_join(., df_aapc) 


# 
# kable(df_table1)
# write.table(df_table1, file = "table1.txt", sep = ",", quote = FALSE, row.names = F)
# # End of command chunk --------------------------------------------------------------------







line <- trendData %>%
  ggplot(., aes(x = Year, y= perc, color = outcome)) +
  geom_point(aes(size = n)) + theme_bw() +
  geom_smooth(method = "lm", se=T, size = 5) +# for those cute glyphs in the legend se=F 
  scale_color_brewer(palette = "Dark2") +
  labs(color="Country", size="Sample Size") +
  xlab("Publication year") + ylab("Prevalence") +
  theme_minimal(base_size = 20) +
  theme(
    legend.position = "bottom",
    legend.title = element_blank(),
    axis.title.x = element_blank(),
    axis.title.y = element_text(size = 15),
    axis.title.y.left = element_text(margin = margin(r = 10)),
    panel.grid.minor = element_blank(),
    plot.margin = margin(t = 30)
  ) +
  scale_x_continuous(limits = c(2011, 2020), breaks=seq(2010,2020,by=2)) 



bar <- df_trend %>% 
  ggplot(., aes(x = outcome, y=rel_incr, fill = outcome)) +
  geom_col(width = 0.75, alpha = 0.9) +
  geom_text(
    aes(label = percent(rel_incr, 0.1, scale = 1)),
    position = position_stack(vjust = 0.5),
    color = "white",
    fontface = "bold",
    size = 5
  ) +
  scale_fill_brewer(palette = "Dark2") +
  scale_y_continuous(expand = expand_scale(0.01, 0.05)) +  # remove extra space between bars and x-axis labels
  labs(y = "Percentage Relative Change (%)") +
  theme_minimal(base_size = 16) + 
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.title.y = element_text(size = 15),
    axis.title.y.left = element_text(margin = margin(r = 10)),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank()
  )

mytheme <- ttheme_default(padding = unit(c(4,4), "mm"),
                          core = list(padding=unit(c(14,18), "mm"),
                                      fg_params = list(hjust=0, x=0.1, 
                                                       y=0.4,
                                                       fontsize=14)),
                          colhead = list(padding=unit(c(4,18), "mm"),
                                         fg_params = list(fontsize=13,  fontface="bold"))
)

tab <- df_table1 %>% 
  transmute(
    Population = outcome,
    `Number \n of studies` = N ,
    `Period \n Start` = firstPeriod,
    `Period \n End` = lastPeriod,
    `Average Annual Percent \n Change (AAPC) (95% CI)` = aapc_effect,
    `P-value` = pvalue
  ) %>% 
  tableGrob(theme = mytheme, rows = NULL)

pdf(file = "./Figures/Figure12_Trend_use_CI.pdf", width = 20, height = 13)
layout <- (bar + tab) / line

layout +
  plot_annotation(
    theme = theme(plot.title =
                    element_text(size = 20, hjust = 0.5, face = "bold"))
  )
dev.off()
